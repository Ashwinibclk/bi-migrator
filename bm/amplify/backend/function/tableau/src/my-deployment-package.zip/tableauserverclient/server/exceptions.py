class NotSignedInError(Exception):
    pass
